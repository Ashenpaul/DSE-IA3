"""
Main Pipeline: career_guidance.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Course: Data Science Ecosystem
Student: ASHEN PAUL P - URK24CS1131
Institution: Karunya Institute of Technology and Sciences
Academic Year: 2026-2027

Executes the end-to-end data science pipeline:
1. Data Acquisition (Official O*NET dataset + Web-scraping sample)
2. Schema Validation, Cleaning, and Reshaping
3. Learner Profile Ingestion (Interactive / Benchmark Profiles)
4. Multi-Metric Similarity Calculation (Cosine, Weighted, Euclidean, Manhattan)
5. Skill-Gap and Deficit Severity Analysis
6. Output Generation: CSV reports, publication figures, and run summary metadata.
"""

import os
import sys
import json
import argparse
import datetime
import logging
import pandas as pd
import numpy as np

# Ensure src modules are resolvable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader import acquire_onet_data, scrape_live_career_skills
from preprocessor import OnetPreprocessor
from similarity_engine import SimilarityEngine
from gap_analyzer import SkillGapAnalyzer
from visualizer import CareerVisualizer

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("CareerGuidance")

# Archetype profiles for rapid demonstration and automated testing across diverse domains
PRESET_PROFILES = {
    "data_science_ai": {
        "Mathematics": 78.0,
        "Programming": 75.0,
        "Critical Thinking": 72.0,
        "Complex Problem Solving": 68.0,
        "Systems Analysis": 62.0,
        "Systems Evaluation": 55.0,
        "Active Learning": 70.0,
        "Reading Comprehension": 70.0,
        "Active Listening": 68.0,
        "Writing": 65.0,
        "Speaking": 60.0,
        "Science": 65.0,
        "Operations Analysis": 58.0,
        "Judgment and Decision Making": 60.0,
        "Time Management": 65.0,
        "Learning Strategies": 64.0,
        "Monitoring": 58.0,
        "Coordination": 55.0,
        "Social Perceptiveness": 52.0,
        "Persuasion": 48.0,
        "Negotiation": 45.0,
        "Instructing": 50.0,
        "Service Orientation": 48.0,
        "Technology Design": 52.0,
        "Quality Control Analysis": 45.0,
        "Management of Personnel Resources": 35.0,
        "Management of Financial Resources": 30.0,
        "Management of Material Resources": 25.0,
        "Operations Monitoring": 50.0,
        "Operation and Control": 35.0,
        "Troubleshooting": 50.0,
        "Equipment Selection": 25.0,
        "Equipment Maintenance": 15.0,
        "Repairing": 10.0
    },
    "software_engineering": {
        "Programming": 95.0,
        "Technology Design": 88.0,
        "Troubleshooting": 88.0,
        "Complex Problem Solving": 84.0,
        "Systems Analysis": 82.0,
        "Critical Thinking": 80.0,
        "Mathematics": 75.0,
        "Active Listening": 70.0,
        "Coordination": 68.0,
        "Time Management": 72.0
    },
    "cybersecurity": {
        "Systems Analysis": 92.0,
        "Systems Evaluation": 90.0,
        "Critical Thinking": 88.0,
        "Operations Monitoring": 84.0,
        "Complex Problem Solving": 84.0,
        "Programming": 78.0,
        "Judgment and Decision Making": 82.0,
        "Troubleshooting": 85.0
    },
    "healthcare_medicine": {
        "Service Orientation": 95.0,
        "Social Perceptiveness": 92.0,
        "Active Listening": 90.0,
        "Science": 88.0,
        "Critical Thinking": 82.0,
        "Judgment and Decision Making": 82.0,
        "Instructing": 80.0,
        "Speaking": 78.0,
        "Monitoring": 78.0,
        "Complex Problem Solving": 72.0
    },
    "business_management": {
        "Management of Financial Resources": 95.0,
        "Management of Personnel Resources": 92.0,
        "Negotiation": 90.0,
        "Persuasion": 90.0,
        "Judgment and Decision Making": 88.0,
        "Speaking": 85.0,
        "Critical Thinking": 82.0,
        "Time Management": 82.0,
        "Coordination": 85.0
    },
    "mechanical_engineering": {
        "Repairing": 95.0,
        "Equipment Maintenance": 92.0,
        "Troubleshooting": 90.0,
        "Operation and Control": 88.0,
        "Equipment Selection": 85.0,
        "Operations Monitoring": 82.0,
        "Technology Design": 78.0,
        "Mathematics": 72.0
    },
    "writing_law": {
        "Writing": 96.0,
        "Reading Comprehension": 96.0,
        "Speaking": 92.0,
        "Active Listening": 90.0,
        "Critical Thinking": 90.0,
        "Judgment and Decision Making": 85.0,
        "Active Learning": 82.0
    }
}


def prompt_interactive_profile(available_skills: list) -> dict:
    """
    Collects learner skill self-ratings interactively across key cross-domain competencies.
    """
    print("\n" + "=" * 68)
    print("        CUSTOM LEARNER SKILL PROFILE INPUT (URK24CS1131)")
    print("  Rate your proficiency on a scale of 0 to 100 for each domain.")
    print("  (Press ENTER directly to keep the suggested default value)")
    print("=" * 68 + "\n")
    
    learner_skills = {}
    
    # 15 diverse cross-domain anchor competencies
    survey_skills = [
        ("Programming", 70.0, "Software coding, algorithmic development"),
        ("Mathematics", 65.0, "Statistical analysis, mathematical logic"),
        ("Science", 55.0, "Empirical research, scientific methods"),
        ("Technology Design", 60.0, "Designing software/engineering solutions"),
        ("Critical Thinking", 75.0, "Evaluating logic, reasoning and arguments"),
        ("Complex Problem Solving", 70.0, "Synthesizing multifaceted solutions"),
        ("Systems Analysis", 60.0, "Analyzing system components & workflow"),
        ("Service Orientation", 50.0, "Actively seeking ways to help people"),
        ("Social Perceptiveness", 50.0, "Awareness of others' behavior & needs"),
        ("Management of Financial Resources", 40.0, "Budgeting, accounting & expenditure"),
        ("Management of Personnel Resources", 40.0, "Motivating, leading & directing staff"),
        ("Negotiation", 45.0, "Reconciling differences & closing deals"),
        ("Writing", 65.0, "Written communication & documentation"),
        ("Speaking", 60.0, "Verbal communication & presentation"),
        ("Equipment Maintenance", 30.0, "Performing routine machinery maintenance"),
        ("Repairing", 25.0, "Repairing machines or physical systems")
    ]

    for sk_name, default_val, desc in survey_skills:
        prompt_txt = f"  * {sk_name:<34} ({desc})\n    [0-100, default={default_val}]: "
        try:
            val_str = input(prompt_txt).strip()
            if not val_str:
                learner_skills[sk_name] = default_val
            else:
                v = float(val_str)
                learner_skills[sk_name] = max(0.0, min(100.0, v))
        except (ValueError, EOFError):
            learner_skills[sk_name] = default_val

    return learner_skills


def run_pipeline(
    scale: str = "composite",
    profile_choice: str = "data_science_ai",
    custom_skills: dict = None,
    interactive: bool = False,
    top_k: int = 10,
    output_dir: str = "outputs"
) -> dict:
    """
    Executes complete end-to-end Career Guidance workflow.
    """
    run_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info("=" * 60)
    logger.info(f"AI-Enhanced Career Guidance Pipeline - Started at {run_timestamp}")
    logger.info("=" * 60)

    os.makedirs(output_dir, exist_ok=True)

    # Step 1: Data Acquisition
    logger.info("Step 1: Dataset Acquisition & Provenance Verification...")
    acq_meta = acquire_onet_data(raw_dir="data/raw")
    scraped_df = scrape_live_career_skills(output_path="data/raw/web_scraped_career_sample.csv")

    # Step 2: Cleaning & Reshaping
    logger.info(f"Step 2: Cleaning, Schema Validation & Matrix Reshaping (Scale={scale})...")
    preprocessor = OnetPreprocessor(raw_dir="data/raw", processed_dir="data/processed")
    matrix_df = preprocessor.clean_and_reshape(scale_preference=scale)

    # Step 3: Learner Skill Vector Ingestion
    logger.info("Step 3: Learner Skill Profile Configuration...")
    if interactive:
        learner_dict = prompt_interactive_profile(list(matrix_df.columns))
    elif custom_skills:
        learner_dict = custom_skills
    else:
        learner_dict = PRESET_PROFILES.get(profile_choice, PRESET_PROFILES["data_science_ai"])

    logger.info(f"Learner Profile Selected: {profile_choice} ({len(learner_dict)} skills defined)")

    # Step 4: Multi-Metric Similarity Matching
    logger.info("Step 4: Computing Similarity Metrics (Cosine, Weighted, Euclidean, Manhattan)...")
    sim_engine = SimilarityEngine(matrix_df)
    learner_vec = sim_engine.align_learner_vector(learner_dict)
    results_df = sim_engine.compute_all_metrics(learner_vec)
    comp_analysis = sim_engine.compare_ranking_methods(results_df, top_k=top_k)

    # Step 5: Skill-Gap Analysis
    logger.info("Step 5: Performing Skill-Gap Deficit Analysis for Top Recommendation...")
    top_match = results_df.iloc[0]
    top_soc = top_match["SOC_Code"]
    top_title = top_match["Occupation_Title"]

    gap_analyzer = SkillGapAnalyzer(matrix_df)
    df_gap = gap_analyzer.analyze_occupation_gap(top_soc, learner_vec)
    gap_summary = gap_analyzer.generate_gap_summary(df_gap)

    # Step 6: Visualizations & Artifacts Generation
    logger.info("Step 6: Generating High-Resolution Publication Visualizations & Interactive Dashboard...")
    viz = CareerVisualizer(output_dir=output_dir)
    chart_matches = viz.plot_top_matches(results_df.head(top_k), filename="top_career_matches.png")
    chart_gap = viz.plot_skill_gaps(df_gap, target_occupation=top_title, filename="skill_gap_comparison.png")
    chart_heatmap = viz.plot_metric_correlation(comp_analysis["rank_correlation_matrix"], filename="metric_correlation_heatmap.png")
    chart_radar = viz.plot_radar_profile(df_gap, target_occupation=top_title, filename="skill_radar_profile.png")
    chart_pca = viz.plot_occupation_space_pca(matrix_df, results_df, learner_vec, filename="occupation_skill_space_pca.png")
    html_dash = viz.generate_interactive_html_dashboard(results_df, df_gap, matrix_df, learner_vec, top_title, filename="interactive_career_dashboard.html")

    # Step 7: Export CSV Files
    rec_csv = os.path.join(output_dir, "career_recommendations.csv")
    top_csv = os.path.join(output_dir, "top_career_matches.csv")
    gap_csv = os.path.join(output_dir, "skill_gap_analysis.csv")
    method_csv = os.path.join(output_dir, "method_comparison.csv")

    results_df.to_csv(rec_csv, index=False)
    results_df.head(top_k).to_csv(top_csv, index=False)
    df_gap.to_csv(gap_csv, index=False)
    comp_analysis["rank_correlation_matrix"].to_csv(method_csv)

    # Step 8: Export Run Summary Provenance
    summary_data = {
        "project": "AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis",
        "student": "ASHEN PAUL P - URK24CS1131",
        "academic_year": "2026-2027",
        "institution": "Karunya Institute of Technology and Sciences",
        "run_timestamp": run_timestamp,
        "dataset_source": "O*NET 30.2 / 31.0 Transferable Skills Dataset",
        "initial_raw_rows": preprocessor.cleaning_stats.get("initial_skill_rows"),
        "retained_cleaned_rows": preprocessor.cleaning_stats.get("retained_skill_rows"),
        "total_occupations_evaluated": len(results_df),
        "total_skills_dimension": len(matrix_df.columns),
        "scale_applied": scale,
        "learner_profile_type": profile_choice,
        "learner_skills_input": learner_dict,
        "top_1_recommendation": {
            "soc_code": top_soc,
            "title": top_title,
            "cosine_similarity": float(top_match["Cosine_Similarity"]),
            "readiness_index": float(top_match["Readiness_Index"])
        },
        "top_10_shortlist": results_df.head(top_k)[["Rank", "SOC_Code", "Occupation_Title", "Cosine_Similarity", "Readiness_Index"]].to_dict(orient="records"),
        "gap_analysis_summary": gap_summary,
        "spearman_rank_correlation_with_weighted": float(comp_analysis["rank_correlation_matrix"].loc["Cosine_Similarity", "Weighted_Cosine_Similarity"]),
        "artifacts_generated": [
            rec_csv, top_csv, gap_csv, method_csv,
            chart_matches, chart_gap, chart_heatmap,
            chart_radar, chart_pca, html_dash
        ]
    }

    summary_json = os.path.join(output_dir, "run_summary.json")
    with open(summary_json, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=4)

    # Configure stdout for safe encoding
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    # Terminal Output Presentation
    print("\n" + "=" * 76)
    print("      >>> AI-ENHANCED CAREER GUIDANCE & SKILL-GAP ENGINE (URK24CS1131) <<<")
    print("=" * 76)
    print(f"  Learner Profile Selected : {profile_choice.upper()}")
    print(f"  Occupations Evaluated    : {len(results_df)} roles across 35 skill dimensions")
    print(f"  Top Recommended Role     : {top_title} (SOC: {top_soc})")
    print(f"  Cosine Similarity Match  : {top_match['Cosine_Similarity']:.2f}%")
    print(f"  Domain Readiness Index   : {top_match['Readiness_Index']:.2f}%")
    print("-" * 76)
    print("  [+] TOP 5 CAREER MATCHES:")
    top_5_table = results_df.head(5)[["Rank", "SOC_Code", "Occupation_Title", "Cosine_Similarity", "Readiness_Index"]].to_string(index=False)
    for line in top_5_table.split("\n"):
        print(f"    {line}")
    print("-" * 76)
    print(f"  [*] TARGET ROLE: {top_title}")
    print("  [!] TOP 3 SKILL GAPS TO BRIDGE:")
    for d in gap_summary["top_priority_growth_areas"][:3]:
        print(f"    * {d['Skill_Name']:<34} Deficit: +{d['Skill_Gap']:>4.1f} | Required: {d['Required_Proficiency']:>4.1f} | Current: {d['Learner_Proficiency']:>4.1f}")
    print("-" * 76)
    print("  [*] VISUAL & INTERACTIVE ARTIFACTS GENERATED:")
    print(f"    [1] Interactive HTML Dashboard : outputs/interactive_career_dashboard.html")
    print(f"    [2] Top Career Matches Chart   : outputs/top_career_matches.png")
    print(f"    [3] Skill-Gap Comparison Bar   : outputs/skill_gap_comparison.png")
    print(f"    [4] Metric Correlation Heatmap : outputs/metric_correlation_heatmap.png")
    print(f"    [5] Polar Skill Radar Profile  : outputs/skill_radar_profile.png")
    print(f"    [6] 2D PCA Skill Space Map     : outputs/occupation_skill_space_pca.png")
    print(f"    [7] CSV Recommendations & Gaps : outputs/*.csv (4 tabular datasets)")
    print("-" * 76)
    print(f"  [TIP] Double-click 'outputs/interactive_career_dashboard.html' or open it")
    print(f"        in Chrome/Edge for an interactive 360-degree visual evaluation experience!")
    print("=" * 76 + "\n")

    return summary_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI-Enhanced Career Guidance System (URK24CS1131)")
    parser.add_argument("--scale", choices=["composite", "IM", "LV"], default="composite", help="Proficiency scale")
    parser.add_argument("--profile", choices=list(PRESET_PROFILES.keys()), default="data_science_ai", help="Preset profile")
    parser.add_argument("--interactive", action="store_true", help="Run interactive terminal prompt")
    parser.add_argument("--top_k", type=int, default=10, help="Number of top matches")
    parser.add_argument("--output_dir", default="outputs", help="Output directory")

    # If executed without CLI flags in an interactive terminal, display selection menu
    if len(sys.argv) == 1 and sys.stdin.isatty():
        print("\n" + "=" * 76)
        print("      AI-ENHANCED CAREER GUIDANCE SYSTEM - SELECT EXPLORATION MODE")
        print("=" * 76)
        print("  [1] Data Science & AI Research         (Top Match: Research Scientists)")
        print("  [2] Software Engineering & Development (Top Match: Computer Programmers)")
        print("  [3] Cybersecurity & Network Defense    (Top Match: Information Security Engineers)")
        print("  [4] Healthcare & Clinical Medicine     (Top Match: Mental Health Counselors / Nursing)")
        print("  [5] Business Management & Finance      (Top Match: Chief Executives / Buyers)")
        print("  [6] Mechanical & Technical Operations  (Top Match: Service Mechanics / Technicians)")
        print("  [7] Creative Writing & Legal Analysis  (Top Match: Technical Writers / Law Clerks)")
        print("  [8] Custom Interactive Skill Rater     (Enter your own personal skill ratings)")
        print("-" * 76)
        try:
            choice = input("  Select option [1-8, Default=1]: ").strip()
        except (EOFError, KeyboardInterrupt):
            choice = "1"

        menu_map = {
            "1": ("data_science_ai", False),
            "2": ("software_engineering", False),
            "3": ("cybersecurity", False),
            "4": ("healthcare_medicine", False),
            "5": ("business_management", False),
            "6": ("mechanical_engineering", False),
            "7": ("writing_law", False),
            "8": ("data_science_ai", True)
        }
        selected_profile, is_interactive = menu_map.get(choice, ("data_science_ai", False))
        run_pipeline(
            scale="composite",
            profile_choice=selected_profile,
            interactive=is_interactive,
            top_k=10,
            output_dir="outputs"
        )
    else:
        args = parser.parse_args()
        run_pipeline(
            scale=args.scale,
            profile_choice=args.profile,
            interactive=args.interactive,
            top_k=args.top_k,
            output_dir=args.output_dir
        )
