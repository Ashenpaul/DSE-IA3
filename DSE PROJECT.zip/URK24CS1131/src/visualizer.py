"""
Module: visualizer.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Student: ASHEN PAUL P - URK24CS1131
Course: Data Science Ecosystem

Generates high-resolution publication-quality visualizations for career recommendations,
skill-gap comparisons, polar radar profiles, 2D PCA occupational mappings, and a
standalone interactive Plotly HTML dashboard.
"""

import os
import json
import logging
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for headless terminal execution
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA

import plotly.graph_objects as go
from plotly.subplots import make_subplots

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Apply publication-ready styling
sns.set_theme(style="whitegrid", font="sans-serif")
plt.rcParams.update({
    "figure.autolayout": True,
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.labelsize": 11,
    "axes.labelweight": "semibold",
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
    "figure.titlesize": 14
})


class CareerVisualizer:
    """
    Renders and exports data science visualization artifacts, including static publication
    PNG figures and an interactive standalone Plotly HTML dashboard.
    """

    def __init__(self, output_dir: str = "outputs"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def plot_top_matches(self, top_matches_df: pd.DataFrame, filename: str = "top_career_matches.png") -> str:
        """
        Creates a horizontal bar chart of the top career recommendations.
        """
        filepath = os.path.join(self.output_dir, filename)
        df_plot = top_matches_df.head(10).iloc[::-1]  # Invert so rank 1 is on top

        fig, ax = plt.subplots(figsize=(10, 6.5), dpi=300)

        # Color gradient based on cosine similarity
        norm = plt.Normalize(df_plot["Cosine_Similarity"].min() - 5, df_plot["Cosine_Similarity"].max() + 5)
        colors = plt.cm.Blues(norm(df_plot["Cosine_Similarity"]))

        bars = ax.barh(
            df_plot["Occupation_Title"],
            df_plot["Cosine_Similarity"],
            color=colors,
            edgecolor="#1f4e79",
            linewidth=1.2,
            height=0.65
        )

        # Annotate bar values
        for bar, val, readiness in zip(bars, df_plot["Cosine_Similarity"], df_plot["Readiness_Index"]):
            ax.text(
                val + 1.2,
                bar.get_y() + bar.get_height() / 2,
                f"{val:.1f}% (Readiness: {readiness:.1f}%)",
                va="center",
                ha="left",
                fontsize=9.5,
                fontweight="bold",
                color="#1a252f"
            )

        ax.set_xlim(0, 105)
        ax.set_xlabel("Cosine Similarity Match Score (%)")
        ax.set_ylabel("Target Occupation")
        ax.set_title("Top Recommended Career Pathways Based on Skill Profile Alignment", pad=14)
        ax.grid(axis="x", linestyle="--", alpha=0.6)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Top matches chart exported to {filepath}")
        return filepath

    def plot_skill_gaps(self, df_gap: pd.DataFrame, target_occupation: str, filename: str = "skill_gap_comparison.png") -> str:
        """
        Visualizes required proficiency vs learner proficiency for the top target occupation.
        Highlights skill deficits and proficiencies using a grouped bar chart.
        """
        filepath = os.path.join(self.output_dir, filename)
        
        # Select top 15 skills by required proficiency to focus on key competencies
        df_plot = df_gap.sort_values(by="Required_Proficiency", ascending=False).head(15).copy()
        df_plot = df_plot.iloc[::-1]  # Invert for readable top-to-bottom layout

        fig, ax = plt.subplots(figsize=(11, 7.5), dpi=300)

        y_indices = np.arange(len(df_plot))
        bar_height = 0.38

        # Bars for Required Proficiency vs Learner Proficiency
        ax.barh(
            y_indices + bar_height / 2,
            df_plot["Required_Proficiency"],
            height=bar_height,
            color="#2b5c8f",
            label="Required Benchmark (O*NET)",
            edgecolor="#1b3958",
            linewidth=0.8
        )

        # Color learner bars green if matching/surplus, coral/red if deficit
        learner_colors = ["#27ae60" if gap <= 0 else "#e74c3c" for gap in df_plot["Skill_Gap"]]
        ax.barh(
            y_indices - bar_height / 2,
            df_plot["Learner_Proficiency"],
            height=bar_height,
            color=learner_colors,
            label="Learner Proficiency (Red = Deficit)",
            edgecolor="#333333",
            linewidth=0.8
        )

        # Annotate gap differences
        for i, (req, cur, gap) in enumerate(zip(df_plot["Required_Proficiency"], df_plot["Learner_Proficiency"], df_plot["Skill_Gap"])):
            max_x = max(req, cur)
            gap_text = f"+{gap:.1f}" if gap > 0 else f"{gap:.1f}"
            gap_color = "#c0392b" if gap > 0 else "#27ae60"
            ax.text(
                max_x + 1.5,
                y_indices[i],
                f"Δ {gap_text}",
                va="center",
                ha="left",
                fontsize=9,
                fontweight="bold",
                color=gap_color
            )

        ax.set_yticks(y_indices)
        ax.set_yticklabels(df_plot["Skill_Name"])
        ax.set_xlim(0, 110)
        ax.set_xlabel("Skill Proficiency Rating (Normalized 0 - 100 Scale)")
        ax.set_title(f"Skill-Gap Analysis: Target Role — {target_occupation}", pad=14)
        ax.legend(loc="lower right", framealpha=0.9)
        ax.grid(axis="x", linestyle="--", alpha=0.6)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Skill gap comparison chart exported to {filepath}")
        return filepath

    def plot_metric_correlation(self, corr_df: pd.DataFrame, filename: str = "metric_correlation_heatmap.png") -> str:
        """
        Plots Spearman rank correlation heatmap across multi-metric similarity algorithms.
        """
        filepath = os.path.join(self.output_dir, filename)

        fig, ax = plt.subplots(figsize=(7.5, 6), dpi=300)

        # Shorten column labels for visual clarity
        clean_labels = [c.replace("_Similarity", "").replace("_", " ") for c in corr_df.columns]

        sns.heatmap(
            corr_df,
            annot=True,
            fmt=".3f",
            cmap="crest",
            vmin=0.0,
            vmax=1.0,
            square=True,
            xticklabels=clean_labels,
            yticklabels=clean_labels,
            cbar_kws={"label": "Spearman Rank Correlation (ρ)"},
            ax=ax
        )

        ax.set_title("Multi-Algorithm Rank Correlation Analysis", pad=14)
        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Algorithm correlation heatmap exported to {filepath}")
        return filepath

    def plot_radar_profile(self, df_gap: pd.DataFrame, target_occupation: str, filename: str = "skill_radar_profile.png") -> str:
        """
        Generates a polar radar/spider chart comparing learner proficiencies vs target occupation benchmarks.
        """
        filepath = os.path.join(self.output_dir, filename)

        # Select top 9 representative skills for readable polygon layout
        key_skills = [
            "Programming", "Mathematics", "Critical Thinking", "Complex Problem Solving",
            "Systems Analysis", "Systems Evaluation", "Active Learning", "Writing", "Speaking"
        ]
        
        # Filter matching rows
        df_radar = df_gap[df_gap["Skill_Name"].isin(key_skills)].copy()
        if len(df_radar) < 5:
            df_radar = df_gap.head(8).copy()

        labels = df_radar["Skill_Name"].tolist()
        learner_vals = df_radar["Learner_Proficiency"].tolist()
        required_vals = df_radar["Required_Proficiency"].tolist()

        # Complete the polygon loop
        labels += [labels[0]]
        learner_vals += [learner_vals[0]]
        required_vals += [required_vals[0]]

        num_vars = len(labels)
        angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=True)

        fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True), dpi=300)

        # Draw Required Benchmark polygon
        ax.plot(angles, required_vals, color="#1f77b4", linewidth=2.2, label=f"Benchmark: {target_occupation[:28]}")
        ax.fill(angles, required_vals, color="#1f77b4", alpha=0.22)

        # Draw Learner Proficiency polygon
        ax.plot(angles, learner_vals, color="#2ca02c", linewidth=2.2, linestyle="--", label="Learner Proficiency")
        ax.fill(angles, learner_vals, color="#2ca02c", alpha=0.18)

        ax.set_theta_offset(np.pi / 2)
        ax.set_theta_direction(-1)
        ax.set_thetagrids(np.degrees(angles[:-1]), labels[:-1], fontsize=10, fontweight="semibold")

        ax.set_ylim(0, 100)
        ax.set_yticks([20, 40, 60, 80, 100])
        ax.set_yticklabels(["20%", "40%", "60%", "80%", "100%"], color="grey", size=8.5)
        ax.set_title(f"Polar Competency Profile Alignment\nTarget Role: {target_occupation}", pad=20, fontsize=13)
        ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1), framealpha=0.9)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Radar profile chart exported to {filepath}")
        return filepath

    def plot_occupation_space_pca(self, matrix_df: pd.DataFrame, results_df: pd.DataFrame, learner_vector: np.ndarray, filename: str = "occupation_skill_space_pca.png") -> str:
        """
        Maps all 894 occupations into a 2D PCA skill space with similarity gradient and marks the learner's position.
        """
        filepath = os.path.join(self.output_dir, filename)

        pca = PCA(n_components=2, random_state=42)
        X_all = matrix_df.values
        X_pca = pca.fit_transform(X_all)

        # Transform learner vector into same 2D PCA space
        u_pca = pca.transform(learner_vector.reshape(1, -1))[0]

        # Map similarity scores to coordinates
        sim_dict = dict(zip(results_df["SOC_Code"], results_df["Cosine_Similarity"]))
        
        if isinstance(matrix_df.index, pd.MultiIndex):
            soc_codes = matrix_df.index.get_level_values(0).tolist()
            titles = matrix_df.index.get_level_values(1).tolist()
        else:
            soc_codes = [str(i) for i in matrix_df.index]
            titles = soc_codes

        sim_scores = np.array([sim_dict.get(soc, 50.0) for soc in soc_codes])

        fig, ax = plt.subplots(figsize=(10.5, 7), dpi=300)

        scatter = ax.scatter(
            X_pca[:, 0], X_pca[:, 1],
            c=sim_scores,
            cmap="viridis",
            s=35,
            alpha=0.68,
            edgecolors="none"
        )

        cbar = plt.colorbar(scatter, ax=ax, pad=0.02)
        cbar.set_label("Cosine Similarity Match Score (%)", fontweight="semibold")

        # Plot learner position as prominent golden star
        ax.scatter(
            u_pca[0], u_pca[1],
            color="#e74c3c",
            edgecolor="#f1c40f",
            linewidth=2.5,
            s=260,
            marker="*",
            label="Learner Profile Vector (Current Position)",
            zorder=10
        )

        # Highlight top 3 career matches with annotations
        top_3_socs = results_df.head(3)["SOC_Code"].tolist()
        for idx, soc in enumerate(soc_codes):
            if soc in top_3_socs:
                ax.annotate(
                    f"{titles[idx][:25]}",
                    (X_pca[idx, 0], X_pca[idx, 1]),
                    xytext=(8, 8),
                    textcoords="offset points",
                    fontsize=8.5,
                    fontweight="bold",
                    color="#1a252f",
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="#ffffff", edgecolor="#34495e", alpha=0.85)
                )

        ax.set_title(
            f"2D PCA Projection of 894 Occupations in 35-Dimensional Skill Space\n"
            f"(Explained Variance: PC1={pca.explained_variance_ratio_[0]:.1%}, PC2={pca.explained_variance_ratio_[1]:.1%})",
            pad=14
        )
        ax.set_xlabel("Principal Component 1 (General Analytical & Quantitative Demand)")
        ax.set_ylabel("Principal Component 2 (Technical vs Resource Management Focus)")
        ax.legend(loc="upper right", framealpha=0.92)
        ax.grid(True, linestyle="--", alpha=0.5)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"PCA occupation space chart exported to {filepath}")
        return filepath

    def generate_interactive_html_dashboard(
        self,
        results_df: pd.DataFrame,
        df_gap: pd.DataFrame,
        matrix_df: pd.DataFrame,
        learner_vector: np.ndarray,
        target_title: str,
        filename: str = "interactive_career_dashboard.html"
    ) -> str:
        """
        Builds a self-contained, publication-ready interactive HTML dashboard using Plotly.
        Can be opened directly in Chrome/Edge without any web server or dependencies.
        """
        filepath = os.path.join(self.output_dir, filename)

        # 1. 2D PCA computation for interactive map
        pca = PCA(n_components=2, random_state=42)
        X_pca = pca.fit_transform(matrix_df.values)
        u_pca = pca.transform(learner_vector.reshape(1, -1))[0]

        if isinstance(matrix_df.index, pd.MultiIndex):
            soc_codes = matrix_df.index.get_level_values(0).tolist()
            titles = matrix_df.index.get_level_values(1).tolist()
        else:
            soc_codes = [str(i) for i in matrix_df.index]
            titles = soc_codes

        sim_dict = dict(zip(results_df["SOC_Code"], results_df["Cosine_Similarity"]))
        readiness_dict = dict(zip(results_df["SOC_Code"], results_df["Readiness_Index"]))
        sim_scores = [sim_dict.get(soc, 0.0) for soc in soc_codes]
        readiness_scores = [readiness_dict.get(soc, 0.0) for soc in soc_codes]

        # 2. Interactive Figure 1: Top 10 Matches Horizontal Bar
        df_top10 = results_df.head(10).iloc[::-1]
        fig_bar = go.Figure(go.Bar(
            x=df_top10["Cosine_Similarity"],
            y=df_top10["Occupation_Title"],
            orientation="h",
            marker=dict(
                color=df_top10["Cosine_Similarity"],
                colorscale="Blues",
                line=dict(color="#1f4e79", width=1.5)
            ),
            text=[f"{v:.1f}% (Readiness: {r:.1f}%)" for v, r in zip(df_top10["Cosine_Similarity"], df_top10["Readiness_Index"])],
            textposition="auto",
            hoverinfo="text",
            hovertext=[f"<b>{t}</b><br>SOC: {s}<br>Cosine Similarity: {c:.2f}%<br>Readiness Index: {r:.2f}%" 
                       for t, s, c, r in zip(df_top10["Occupation_Title"], df_top10["SOC_Code"], df_top10["Cosine_Similarity"], df_top10["Readiness_Index"])]
        ))
        fig_bar.update_layout(
            title="<b>Top 10 Career Pathway Recommendations</b>",
            xaxis=dict(title="Cosine Similarity Match (%)", range=[0, 105]),
            yaxis=dict(title=""),
            height=400,
            margin=dict(l=10, r=20, t=40, b=30),
            template="plotly_white"
        )

        # 3. Interactive Figure 2: Polar Radar Chart
        key_skills = [
            "Programming", "Mathematics", "Critical Thinking", "Complex Problem Solving",
            "Systems Analysis", "Systems Evaluation", "Active Learning", "Writing", "Speaking"
        ]
        df_radar = df_gap[df_gap["Skill_Name"].isin(key_skills)].copy()
        if len(df_radar) < 5:
            df_radar = df_gap.head(8).copy()

        radar_skills = df_radar["Skill_Name"].tolist()
        radar_learner = df_radar["Learner_Proficiency"].tolist()
        radar_req = df_radar["Required_Proficiency"].tolist()

        fig_radar = go.Figure()
        fig_radar.add_trace(go.Scatterpolar(
            r=radar_req + [radar_req[0]],
            theta=radar_skills + [radar_skills[0]],
            fill='toself',
            name=f'Benchmark: {target_title[:22]}',
            line=dict(color='#2b5c8f', width=2),
            fillcolor='rgba(43, 92, 143, 0.25)'
        ))
        fig_radar.add_trace(go.Scatterpolar(
            r=radar_learner + [radar_learner[0]],
            theta=radar_skills + [radar_skills[0]],
            fill='toself',
            name='Learner Proficiency',
            line=dict(color='#27ae60', width=2, dash='dash'),
            fillcolor='rgba(39, 174, 96, 0.22)'
        ))
        fig_radar.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
            title="<b>Polar Competency Radar Alignment</b>",
            height=400,
            margin=dict(l=40, r=40, t=40, b=30),
            template="plotly_white"
        )

        # 4. Interactive Figure 3: 2D Occupation Space Scatter Map
        hover_texts = [
            f"<b>{t}</b><br>SOC: {s}<br>Cosine Match: {c:.1f}%<br>Readiness: {r:.1f}%"
            for t, s, c, r in zip(titles, soc_codes, sim_scores, readiness_scores)
        ]

        fig_scatter = go.Figure()
        fig_scatter.add_trace(go.Scatter(
            x=X_pca[:, 0],
            y=X_pca[:, 1],
            mode="markers",
            marker=dict(
                size=7,
                color=sim_scores,
                colorscale="Viridis",
                showscale=True,
                colorbar=dict(title="Cosine Match %")
            ),
            text=hover_texts,
            hoverinfo="text",
            name="Occupations (894)"
        ))
        # Add student marker
        fig_scatter.add_trace(go.Scatter(
            x=[u_pca[0]],
            y=[u_pca[1]],
            mode="markers+text",
            marker=dict(size=18, color="#e74c3c", symbol="star", line=dict(color="#f1c40f", width=2)),
            text=["<b>Learner Position</b>"],
            textposition="top center",
            hoverinfo="text",
            hovertext="<b>Your Current Skill Endowment Vector</b>",
            name="Learner Vector"
        ))
        fig_scatter.update_layout(
            title=f"<b>2D PCA Occupational Skill Space Map (894 Occupations)</b>",
            xaxis=dict(title=f"PC 1 ({pca.explained_variance_ratio_[0]:.1%} variance explained)"),
            yaxis=dict(title=f"PC 2 ({pca.explained_variance_ratio_[1]:.1%} variance explained)"),
            height=450,
            margin=dict(l=20, r=20, t=40, b=30),
            template="plotly_white"
        )

        # 5. Build Complete HTML Page with Bootstrap Styling
        top_row = results_df.iloc[0]
        deficits = df_gap[df_gap["Skill_Gap"] > 0]
        surpluses = df_gap[df_gap["Skill_Gap"] <= 0]

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI-Enhanced Career Guidance Dashboard | URK24CS1131</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
    <style>
        body {{ background-color: #f8f9fa; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }}
        .metric-card {{ background: #fff; border-radius: 10px; border-left: 5px solid #0d6efd; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 18px; margin-bottom: 20px; }}
        .metric-card.success {{ border-left-color: #198754; }}
        .metric-card.warning {{ border-left-color: #ffc107; }}
        .metric-card.danger {{ border-left-color: #dc3545; }}
        .chart-container {{ background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 15px; margin-bottom: 25px; }}
        .table-container {{ background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 20px; margin-bottom: 30px; }}
        .badge-deficit {{ background-color: #dc3545; color: white; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-size: 0.82rem; }}
        .badge-surplus {{ background-color: #198754; color: white; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-size: 0.82rem; }}
    </style>
</head>
<body>
    <div class="container-fluid py-4 px-lg-5">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom">
            <div>
                <h2 class="fw-bold mb-1 text-primary">AI-Enhanced Career Guidance & Skill-Gap Analytics</h2>
                <p class="text-muted mb-0"><b>Candidate:</b> ASHEN PAUL P (URK24CS1131) | <b>Course:</b> Data Science Ecosystem | <b>Institution:</b> Karunya Institute of Technology and Sciences</p>
            </div>
            <div class="text-end">
                <span class="badge bg-secondary p-2">Dataset: O*NET 31.0 Transferable Skills</span>
                <span class="badge bg-primary p-2">894 Occupations × 35 Dimensions</span>
            </div>
        </div>

        <!-- Metric KPI Cards -->
        <div class="row">
            <div class="col-md-3">
                <div class="metric-card">
                    <small class="text-muted text-uppercase fw-bold">Top Recommended Pathway</small>
                    <h5 class="fw-bold text-dark mt-1 mb-1">{top_row['Occupation_Title']}</h5>
                    <small class="text-muted">SOC Code: {top_row['SOC_Code']}</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-card success">
                    <small class="text-muted text-uppercase fw-bold">Cosine Vector Similarity</small>
                    <h2 class="fw-bold text-success mt-1 mb-0">{top_row['Cosine_Similarity']:.1f}%</h2>
                    <small class="text-muted">Weighted Cosine: {top_row['Weighted_Cosine_Similarity']:.1f}%</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-card warning">
                    <small class="text-muted text-uppercase fw-bold">Domain Readiness Index</small>
                    <h2 class="fw-bold text-warning mt-1 mb-0">{top_row['Readiness_Index']:.1f}%</h2>
                    <small class="text-muted">Core Benchmark Proficiencies Met</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-card danger">
                    <small class="text-muted text-uppercase fw-bold">Skill Deficits to Bridge</small>
                    <h2 class="fw-bold text-danger mt-1 mb-0">{len(deficits)} <span class="fs-6 text-muted font-normal">/ {len(df_gap)} skills</span></h2>
                    <small class="text-success fw-semibold">{len(surpluses)} Skills Meet/Exceed Benchmark</small>
                </div>
            </div>
        </div>

        <!-- Charts Row 1: Bar Chart & Radar Chart -->
        <div class="row">
            <div class="col-lg-6">
                <div class="chart-container">
                    {fig_bar.to_html(full_html=False, include_plotlyjs=False)}
                </div>
            </div>
            <div class="col-lg-6">
                <div class="chart-container">
                    {fig_radar.to_html(full_html=False, include_plotlyjs=False)}
                </div>
            </div>
        </div>

        <!-- Charts Row 2: 2D PCA Space Scatter Map -->
        <div class="row">
            <div class="col-12">
                <div class="chart-container">
                    {fig_scatter.to_html(full_html=False, include_plotlyjs=False)}
                    <small class="text-muted d-block mt-2">💡 <i>Tip: Click and drag to zoom into specific clusters. Hover over any dot to view the exact job title and similarity match. The red star indicates your current skill endowment vector.</i></small>
                </div>
            </div>
        </div>

        <!-- Table Row: Detailed Skill Gap Diagnostics -->
        <div class="row">
            <div class="col-12">
                <div class="table-container">
                    <h4 class="fw-bold mb-3">Itemized Skill-Gap Diagnostic Breakdown (Target: {target_title})</h4>
                    <p class="text-muted">Direct mathematical difference between target occupational benchmark (<span class="badge bg-primary">Required</span>) and your self-reported proficiency (<span class="badge bg-success">Learner</span>). Positive gaps (&Delta; > 0) highlight priority growth areas.</p>
                    <div class="table-responsive">
                        <table class="table table-hover table-striped align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th>Skill Descriptor</th>
                                    <th>Required Benchmark</th>
                                    <th>Your Proficiency</th>
                                    <th>Gap Severity (&Delta;)</th>
                                    <th>Status</th>
                                    <th>Recommended Learning Pathway</th>
                                </tr>
                            </thead>
                            <tbody>"""

        for _, row in df_gap.iterrows():
            gap = row["Skill_Gap"]
            if gap > 0:
                badge = f'<span class="badge-deficit">Deficit +{gap:.1f}</span>'
            else:
                badge = f'<span class="badge-surplus">Surplus {gap:.1f}</span>'

            html_content += f"""
                                <tr>
                                    <td class="fw-semibold">{row['Skill_Name']}</td>
                                    <td>{row['Required_Proficiency']:.1f}%</td>
                                    <td>{row['Learner_Proficiency']:.1f}%</td>
                                    <td>{badge}</td>
                                    <td><small class="fw-semibold text-muted">{row['Status']}</small></td>
                                    <td><small>{row['Recommended_Action']}</small></td>
                                </tr>"""

        html_content += """
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <footer class="text-center text-muted py-3 border-top">
            <small>Data Science Ecosystem Course Project &bull; URK24CS1131 &bull; Karunya Institute of Technology and Sciences</small>
        </footer>
    </div>
</body>
</html>"""

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html_content)

        logger.info(f"Interactive HTML dashboard exported to {filepath}")
        return filepath
