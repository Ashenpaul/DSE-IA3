"""
Functional Tests: test_functional.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Student: ASHEN PAUL P - URK24CS1131
Course: Data Science Ecosystem

Implements automated unit and integration tests verifying:
- Valid skill input produces a sorted shortlist
- Unknown descriptors are rejected/skipped gracefully
- Empty profile detection and prevention
- Metric consistency and mathematical properties
- CSV output validity and row counts
"""

import os
import unittest
import numpy as np
import pandas as pd

from src.similarity_engine import SimilarityEngine
from src.gap_analyzer import SkillGapAnalyzer


class TestCareerGuidancePipeline(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Create a synthetic representative occupation-skill matrix for unit testing
        cls.skills = [
            "Programming", "Mathematics", "Critical Thinking", "Complex Problem Solving",
            "Systems Analysis", "Writing", "Speaking", "Reading Comprehension"
        ]
        cls.occupations = [
            ("15-2051.00", "Data Scientists"),
            ("15-1252.00", "Software Developers"),
            ("27-3042.00", "Technical Writers"),
            ("25-1022.00", "Mathematical Science Teachers")
        ]
        
        index = pd.MultiIndex.from_tuples(cls.occupations, names=["O*NET-SOC Code", "Title"])
        data = np.array([
            [85.0, 90.0, 85.0, 88.0, 82.0, 70.0, 68.0, 80.0],  # Data Scientist
            [95.0, 75.0, 80.0, 85.0, 80.0, 60.0, 62.0, 75.0],  # Software Developer
            [25.0, 30.0, 75.0, 60.0, 50.0, 95.0, 90.0, 92.0],  # Technical Writer
            [50.0, 95.0, 85.0, 80.0, 70.0, 78.0, 92.0, 85.0],  # Math Teacher
        ])
        cls.mock_matrix = pd.DataFrame(data, index=index, columns=cls.skills)
        cls.engine = SimilarityEngine(cls.mock_matrix)
        cls.gap_analyzer = SkillGapAnalyzer(cls.mock_matrix)

    def test_valid_input_produces_sorted_shortlist(self):
        """Verify that valid input returns descending cosine similarity scores."""
        learner_dict = {"Programming": 85.0, "Mathematics": 90.0, "Critical Thinking": 85.0}
        vec = self.engine.align_learner_vector(learner_dict)
        results = self.engine.compute_all_metrics(vec)

        self.assertEqual(len(results), len(self.occupations))
        # Ensure scores strictly descend
        scores = results["Cosine_Similarity"].tolist()
        self.assertTrue(all(scores[i] >= scores[i+1] for i in range(len(scores)-1)))
        # Top occupation should be a leading computing/data role
        self.assertIn(results.iloc[0]["SOC_Code"], ["15-2051.00", "15-1252.00"])

    def test_unknown_descriptors_are_skipped(self):
        """Verify that invalid/hallucinated skill names are skipped without crashing."""
        learner_dict = {
            "Programming": 80.0,
            "NonExistentAlienSkill": 99.0,
            "FakeSkill123": 50.0
        }
        vec = self.engine.align_learner_vector(learner_dict)
        self.assertGreater(np.sum(vec), 0)
        # Programming should be positioned correctly
        prog_idx = self.skills.index("Programming")
        self.assertEqual(vec[prog_idx], 80.0)

    def test_empty_profile_raises_error(self):
        """Verify that an empty/all-zero profile raises ValueError to avoid misleading rankings."""
        empty_vec = np.zeros(len(self.skills))
        with self.assertRaises(ValueError):
            self.engine.compute_all_metrics(empty_vec)

    def test_multi_metric_properties(self):
        """Verify that all similarity metrics return bounded values between 0 and 100%."""
        learner_dict = {"Programming": 70.0, "Writing": 80.0}
        vec = self.engine.align_learner_vector(learner_dict)
        results = self.engine.compute_all_metrics(vec)

        for col in ["Cosine_Similarity", "Weighted_Cosine_Similarity", "Euclidean_Similarity", "Manhattan_Similarity", "Readiness_Index"]:
            self.assertTrue((results[col] >= 0.0).all())
            self.assertTrue((results[col] <= 100.0).all())

    def test_gap_analysis_calculations(self):
        """Verify skill gap calculations correctly distinguish deficits from surpluses."""
        learner_dict = {"Programming": 95.0, "Writing": 30.0}
        vec = self.engine.align_learner_vector(learner_dict)
        # Check against Technical Writer (Requires Writing=95, Programming=25)
        df_gap = self.gap_analyzer.analyze_occupation_gap("27-3042.00", vec)

        writing_row = df_gap[df_gap["Skill_Name"] == "Writing"].iloc[0]
        prog_row = df_gap[df_gap["Skill_Name"] == "Programming"].iloc[0]

        # Writing has gap: 95 - 30 = 65 deficit
        self.assertEqual(writing_row["Skill_Gap"], 65.0)
        self.assertEqual(writing_row["Status"], "Skill Deficit (Growth Area)")

        # Programming has surplus: 25 - 95 = -70 surplus
        self.assertEqual(prog_row["Skill_Gap"], -70.0)
        self.assertEqual(prog_row["Status"], "Proficiency Surplus")


if __name__ == "__main__":
    unittest.main()
