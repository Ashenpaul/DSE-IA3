"""
Module: visualizer.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Student: ASHEN PAUL P - URK24CS1131
Course: Data Science Ecosystem

Generates high-resolution publication-quality visualizations for career recommendations,
skill-gap comparisons, and multi-metric algorithm correlation analyses.
"""

import os
import logging
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for headless terminal execution
import matplotlib.pyplot as plt
import seaborn as sns

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Apply publication-ready styling
sns.set_theme(style="whitegrid", font="sans-serif")
plt.rcParams.update({
    "figure.autolayout": True,
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
    "axes.labelsize": 11,
    "axes.labelweight": "semibold",
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
    "figure.titlesize": 14
})


class CareerVisualizer:
    """
    Renders and exports data science visualization artifacts.
    """

    def __init__(self, output_dir: str = "outputs"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def plot_top_matches(self, top_matches_df: pd.DataFrame, filename: str = "top_career_matches.png") -> str:
        """
        Creates a horizontal bar chart of the top career recommendations.
        """
        filepath = os.path.join(self.output_dir, filename)
        df_plot = top_matches_df.head(10).iloc[::-1]  # Invert so rank 1 is on top

        fig, ax = plt.subplots(figsize=(10, 6.5), dpi=300)

        # Color gradient based on cosine similarity
        norm = plt.Normalize(df_plot["Cosine_Similarity"].min() - 5, df_plot["Cosine_Similarity"].max() + 5)
        colors = plt.cm.Blues(norm(df_plot["Cosine_Similarity"]))

        bars = ax.barh(
            df_plot["Occupation_Title"],
            df_plot["Cosine_Similarity"],
            color=colors,
            edgecolor="#1f4e79",
            linewidth=1.2,
            height=0.65
        )

        # Annotate bar values
        for bar, val, readiness in zip(bars, df_plot["Cosine_Similarity"], df_plot["Readiness_Index"]):
            ax.text(
                val + 1.2,
                bar.get_y() + bar.get_height() / 2,
                f"{val:.1f}% (Readiness: {readiness:.1f}%)",
                va="center",
                ha="left",
                fontsize=9.5,
                fontweight="bold",
                color="#1a252f"
            )

        ax.set_xlim(0, 105)
        ax.set_xlabel("Cosine Similarity Match Score (%)")
        ax.set_ylabel("Target Occupation")
        ax.set_title("Top Recommended Career Pathways Based on Skill Profile Alignment", pad=14)
        ax.grid(axis="x", linestyle="--", alpha=0.6)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Top matches chart exported to {filepath}")
        return filepath

    def plot_skill_gaps(self, df_gap: pd.DataFrame, target_occupation: str, filename: str = "skill_gap_comparison.png") -> str:
        """
        Visualizes required proficiency vs learner proficiency for the top target occupation.
        Highlights skill deficits and proficiencies using a grouped bar chart.
        """
        filepath = os.path.join(self.output_dir, filename)
        
        # Select top 15 skills by required proficiency to focus on key competencies
        df_plot = df_gap.sort_values(by="Required_Proficiency", ascending=False).head(15).copy()
        df_plot = df_plot.iloc[::-1]  # Invert for readable top-to-bottom layout

        fig, ax = plt.subplots(figsize=(11, 7.5), dpi=300)

        y_indices = np.arange(len(df_plot))
        bar_height = 0.38

        # Bars for Required Proficiency vs Learner Proficiency
        ax.barh(
            y_indices + bar_height / 2,
            df_plot["Required_Proficiency"],
            height=bar_height,
            color="#2b5c8f",
            label="Required Benchmark (O*NET)",
            edgecolor="#1b3958",
            linewidth=0.8
        )

        # Color learner bars green if matching/surplus, coral/red if deficit
        learner_colors = ["#27ae60" if gap <= 0 else "#e74c3c" for gap in df_plot["Skill_Gap"]]
        ax.barh(
            y_indices - bar_height / 2,
            df_plot["Learner_Proficiency"],
            height=bar_height,
            color=learner_colors,
            label="Learner Proficiency (Red = Deficit)",
            edgecolor="#333333",
            linewidth=0.8
        )

        # Annotate gap differences
        for i, (req, cur, gap) in enumerate(zip(df_plot["Required_Proficiency"], df_plot["Learner_Proficiency"], df_plot["Skill_Gap"])):
            max_x = max(req, cur)
            gap_text = f"+{gap:.1f}" if gap > 0 else f"{gap:.1f}"
            gap_color = "#c0392b" if gap > 0 else "#27ae60"
            ax.text(
                max_x + 1.5,
                y_indices[i],
                f"Δ {gap_text}",
                va="center",
                ha="left",
                fontsize=9,
                fontweight="bold",
                color=gap_color
            )

        ax.set_yticks(y_indices)
        ax.set_yticklabels(df_plot["Skill_Name"])
        ax.set_xlim(0, 110)
        ax.set_xlabel("Skill Proficiency Rating (Normalized 0 - 100 Scale)")
        ax.set_title(f"Skill-Gap Analysis: Target Role — {target_occupation}", pad=14)
        ax.legend(loc="lower right", framealpha=0.9)
        ax.grid(axis="x", linestyle="--", alpha=0.6)

        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Skill gap comparison chart exported to {filepath}")
        return filepath

    def plot_metric_correlation(self, corr_df: pd.DataFrame, filename: str = "metric_correlation_heatmap.png") -> str:
        """
        Plots Spearman rank correlation heatmap across multi-metric similarity algorithms.
        """
        filepath = os.path.join(self.output_dir, filename)

        fig, ax = plt.subplots(figsize=(7.5, 6), dpi=300)

        # Shorten column labels for visual clarity
        clean_labels = [c.replace("_Similarity", "").replace("_", " ") for c in corr_df.columns]

        sns.heatmap(
            corr_df,
            annot=True,
            fmt=".3f",
            cmap="crest",
            vmin=0.0,
            vmax=1.0,
            square=True,
            xticklabels=clean_labels,
            yticklabels=clean_labels,
            cbar_kws={"label": "Spearman Rank Correlation (ρ)"},
            ax=ax
        )

        ax.set_title("Multi-Algorithm Rank Correlation Analysis", pad=14)
        plt.savefig(filepath, bbox_inches="tight")
        plt.close(fig)
        logger.info(f"Algorithm correlation heatmap exported to {filepath}")
        return filepath
