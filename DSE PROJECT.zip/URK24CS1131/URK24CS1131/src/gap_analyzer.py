"""
Module: gap_analyzer.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Student: ASHEN PAUL P - URK24CS1131
Course: Data Science Ecosystem

Performs skill-gap analysis comparing learner proficiencies with occupational benchmarks,
calculating deficit severities, skill surpluses, and actionable development recommendations.
"""

import logging
import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Curated actionable learning pathway suggestions for core transferable skills
SKILL_DEVELOPMENT_RESOURCES = {
    "Programming": "Complete data structures & algorithms tracks, build end-to-end Python/SQL projects, and contribute to GitHub open-source.",
    "Mathematics": "Review discrete mathematics, linear algebra, calculus for machine learning, and statistical probability distributions.",
    "Critical Thinking": "Practice case studies, evaluate research papers, and analyze algorithmic trade-offs in systems engineering.",
    "Complex Problem Solving": "Tackle multi-component system design, Kaggle competitions, and modular architectural problems.",
    "Systems Analysis": "Study system architecture patterns, data pipeline design, distributed computing, and workflow modeling.",
    "Systems Evaluation": "Perform performance benchmarking, code profiling, latency/throughput evaluation, and A/B testing methodologies.",
    "Active Learning": "Engage with latest technical documentation, subscribe to arXiv/IEEE papers, and implement reproducible research notebooks.",
    "Writing": "Author technical documentation, write structured project reports, and publish explanatory developer blogs.",
    "Speaking": "Deliver technical presentations, participate in seminar peer-reviews, and conduct mock technical interview walkthroughs.",
    "Reading Comprehension": "Read standard technical specifications, API documentation, and foundational academic computer science papers.",
    "Operations Analysis": "Analyze workflow bottlenecks, optimize database query execution plans, and evaluate compute resource utilization.",
    "Judgment and Decision Making": "Apply cost-benefit analysis to architectural decisions, trade-offs between accuracy vs compute, and risk modeling."
}

DEFAULT_RESOURCE = "Engage in targeted project-based learning, complete structured online coursework, and document practical implementations in your portfolio."


class SkillGapAnalyzer:
    """
    Analyzes skill gaps between learner ratings and target occupation requirements.
    """

    def __init__(self, matrix_df: pd.DataFrame):
        self.matrix_df = matrix_df
        self.skills = list(matrix_df.columns)

    def analyze_occupation_gap(self, soc_code: str, learner_vector: np.ndarray) -> pd.DataFrame:
        """
        Calculates skill-by-skill differences for a specific target occupation.
        """
        # Retrieve row corresponding to soc_code
        if isinstance(self.matrix_df.index, pd.MultiIndex):
            matches = self.matrix_df.xs(soc_code, level=0, drop_level=False)
            if matches.empty:
                raise KeyError(f"SOC Code '{soc_code}' not found in occupation matrix.")
            occ_title = matches.index.get_level_values(1)[0]
            required_skills = matches.values[0]
        else:
            if soc_code not in self.matrix_df.index:
                raise KeyError(f"SOC Code '{soc_code}' not found in occupation matrix.")
            occ_title = str(soc_code)
            required_skills = self.matrix_df.loc[soc_code].values

        learner_ratings = learner_vector.astype(float)
        required_ratings = required_skills.astype(float)

        # Gap = Target Requirement - Learner Proficiency
        # Positive values represent skill deficits to be bridged
        gap_values = required_ratings - learner_ratings
        
        records = []
        for i, skill in enumerate(self.skills):
            req = round(float(required_ratings[i]), 2)
            cur = round(float(learner_ratings[i]), 2)
            gap = round(float(gap_values[i]), 2)

            if gap > 0:
                status = "Skill Deficit (Growth Area)"
                # Relative severity percentage
                rel_deficit = round((gap / max(req, 1.0)) * 100.0, 1)
            elif gap == 0:
                status = "Exact Match"
                rel_deficit = 0.0
            else:
                status = "Proficiency Surplus"
                rel_deficit = 0.0

            action = SKILL_DEVELOPMENT_RESOURCES.get(skill, DEFAULT_RESOURCE) if gap > 0 else "Benchmark met; maintain proficiency."

            records.append({
                "SOC_Code": soc_code,
                "Occupation_Title": occ_title,
                "Skill_Name": skill,
                "Required_Proficiency": req,
                "Learner_Proficiency": cur,
                "Skill_Gap": gap,
                "Relative_Deficit_Pct": rel_deficit,
                "Status": status,
                "Recommended_Action": action
            })

        df_gap = pd.DataFrame(records)
        # Sort so that highest skill deficits appear first
        df_gap = df_gap.sort_values(by="Skill_Gap", ascending=False).reset_index(drop=True)
        return df_gap

    def generate_gap_summary(self, df_gap: pd.DataFrame) -> dict:
        """
        Produces high-level executive metrics regarding the learner's skill gap.
        """
        deficits = df_gap[df_gap["Skill_Gap"] > 0]
        surpluses = df_gap[df_gap["Skill_Gap"] < 0]
        matches = df_gap[df_gap["Skill_Gap"] == 0]

        top_deficits = deficits.head(5)[["Skill_Name", "Skill_Gap", "Required_Proficiency", "Learner_Proficiency"]].to_dict(orient="records")

        return {
            "total_skills_evaluated": len(df_gap),
            "deficits_count": len(deficits),
            "matches_count": len(matches),
            "surpluses_count": len(surpluses),
            "average_deficit_magnitude": round(float(deficits["Skill_Gap"].mean()) if not deficits.empty else 0.0, 2),
            "max_deficit_skill": deficits.iloc[0]["Skill_Name"] if not deficits.empty else None,
            "max_deficit_value": float(deficits.iloc[0]["Skill_Gap"]) if not deficits.empty else 0.0,
            "top_priority_growth_areas": top_deficits
        }
