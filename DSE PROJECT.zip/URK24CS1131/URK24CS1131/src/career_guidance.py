"""
Main Pipeline: career_guidance.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Course: Data Science Ecosystem
Student: ASHEN PAUL P - URK24CS1131
Institution: Karunya Institute of Technology and Sciences
Academic Year: 2026-2027

Executes the end-to-end data science pipeline:
1. Data Acquisition (Official O*NET dataset + Web-scraping sample)
2. Schema Validation, Cleaning, and Reshaping
3. Learner Profile Ingestion (Interactive / Benchmark Profiles)
4. Multi-Metric Similarity Calculation (Cosine, Weighted, Euclidean, Manhattan)
5. Skill-Gap and Deficit Severity Analysis
6. Output Generation: CSV reports, publication figures, and run summary metadata.
"""

import os
import sys
import json
import argparse
import datetime
import logging
import pandas as pd
import numpy as np

# Ensure src modules are resolvable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader import acquire_onet_data, scrape_live_career_skills
from preprocessor import OnetPreprocessor
from similarity_engine import SimilarityEngine
from gap_analyzer import SkillGapAnalyzer
from visualizer import CareerVisualizer

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("CareerGuidance")

# Archetype profiles for rapid demonstration and automated testing
PRESET_PROFILES = {
    "data_science_ai": {
        "Mathematics": 78.0,
        "Programming": 75.0,
        "Critical Thinking": 72.0,
        "Complex Problem Solving": 68.0,
        "Systems Analysis": 62.0,
        "Systems Evaluation": 55.0,
        "Active Learning": 70.0,
        "Reading Comprehension": 70.0,
        "Active Listening": 68.0,
        "Writing": 65.0,
        "Speaking": 60.0,
        "Science": 65.0,
        "Operations Analysis": 58.0,
        "Judgment and Decision Making": 60.0,
        "Time Management": 65.0,
        "Learning Strategies": 64.0,
        "Monitoring": 58.0,
        "Coordination": 55.0,
        "Social Perceptiveness": 52.0,
        "Persuasion": 48.0,
        "Negotiation": 45.0,
        "Instructing": 50.0,
        "Service Orientation": 48.0,
        "Technology Design": 52.0,
        "Quality Control Analysis": 45.0,
        "Management of Personnel Resources": 35.0,
        "Management of Financial Resources": 30.0,
        "Management of Material Resources": 25.0,
        "Operations Monitoring": 50.0,
        "Operation and Control": 35.0,
        "Troubleshooting": 50.0,
        "Equipment Selection": 25.0,
        "Equipment Maintenance": 15.0,
        "Repairing": 10.0
    },
    "software_engineering": {
        "Programming": 92.0,
        "Technology Design": 85.0,
        "Troubleshooting": 88.0,
        "Complex Problem Solving": 84.0,
        "Systems Analysis": 82.0,
        "Critical Thinking": 80.0,
        "Mathematics": 75.0,
        "Active Listening": 70.0,
        "Coordination": 68.0,
        "Time Management": 72.0
    },
    "cybersecurity": {
        "Systems Analysis": 90.0,
        "Systems Evaluation": 88.0,
        "Critical Thinking": 86.0,
        "Operations Monitoring": 82.0,
        "Complex Problem Solving": 84.0,
        "Programming": 78.0,
        "Judgment and Decision Making": 80.0,
        "Troubleshooting": 82.0
    }
}


def prompt_interactive_profile(available_skills: list) -> dict:
    """
    Collects learner skill self-ratings interactively via the terminal.
    """
    print("\n=======================================================")
    print("  INTERACTIVE LEARNER SKILL PROFILE INPUT")
    print("  Rate your proficiency on a scale of 0 to 100")
    print("  (or press ENTER to accept default recommended rating)")
    print("=======================================================\n")
    
    learner_skills = {}
    key_skills = [
        "Programming", "Mathematics", "Critical Thinking", "Complex Problem Solving",
        "Systems Analysis", "Systems Evaluation", "Active Learning", "Writing",
        "Speaking", "Reading Comprehension", "Operations Analysis", "Judgment and Decision Making"
    ]

    for sk in key_skills:
        default_val = 75.0 if sk in ["Programming", "Mathematics", "Critical Thinking"] else 60.0
        val_str = input(f"Proficiency for '{sk}' [0-100, default={default_val}]: ").strip()
        if not val_str:
            learner_skills[sk] = default_val
        else:
            try:
                v = float(val_str)
                learner_skills[sk] = max(0.0, min(100.0, v))
            except ValueError:
                print(f"Invalid input; applying default {default_val}")
                learner_skills[sk] = default_val

    return learner_skills


def run_pipeline(
    scale: str = "composite",
    profile_choice: str = "data_science_ai",
    custom_skills: dict = None,
    interactive: bool = False,
    top_k: int = 10,
    output_dir: str = "outputs"
) -> dict:
    """
    Executes complete end-to-end Career Guidance workflow.
    """
    run_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info("=" * 60)
    logger.info(f"AI-Enhanced Career Guidance Pipeline - Started at {run_timestamp}")
    logger.info("=" * 60)

    os.makedirs(output_dir, exist_ok=True)

    # Step 1: Data Acquisition
    logger.info("Step 1: Dataset Acquisition & Provenance Verification...")
    acq_meta = acquire_onet_data(raw_dir="data/raw")
    scraped_df = scrape_live_career_skills(output_path="data/raw/web_scraped_career_sample.csv")

    # Step 2: Cleaning & Reshaping
    logger.info(f"Step 2: Cleaning, Schema Validation & Matrix Reshaping (Scale={scale})...")
    preprocessor = OnetPreprocessor(raw_dir="data/raw", processed_dir="data/processed")
    matrix_df = preprocessor.clean_and_reshape(scale_preference=scale)

    # Step 3: Learner Skill Vector Ingestion
    logger.info("Step 3: Learner Skill Profile Configuration...")
    if interactive:
        learner_dict = prompt_interactive_profile(list(matrix_df.columns))
    elif custom_skills:
        learner_dict = custom_skills
    else:
        learner_dict = PRESET_PROFILES.get(profile_choice, PRESET_PROFILES["data_science_ai"])

    logger.info(f"Learner Profile Selected: {profile_choice} ({len(learner_dict)} skills defined)")

    # Step 4: Multi-Metric Similarity Matching
    logger.info("Step 4: Computing Similarity Metrics (Cosine, Weighted, Euclidean, Manhattan)...")
    sim_engine = SimilarityEngine(matrix_df)
    learner_vec = sim_engine.align_learner_vector(learner_dict)
    results_df = sim_engine.compute_all_metrics(learner_vec)
    comp_analysis = sim_engine.compare_ranking_methods(results_df, top_k=top_k)

    # Step 5: Skill-Gap Analysis
    logger.info("Step 5: Performing Skill-Gap Deficit Analysis for Top Recommendation...")
    top_match = results_df.iloc[0]
    top_soc = top_match["SOC_Code"]
    top_title = top_match["Occupation_Title"]

    gap_analyzer = SkillGapAnalyzer(matrix_df)
    df_gap = gap_analyzer.analyze_occupation_gap(top_soc, learner_vec)
    gap_summary = gap_analyzer.generate_gap_summary(df_gap)

    # Step 6: Visualizations & Artifacts Generation
    logger.info("Step 6: Generating High-Resolution Visualizations...")
    viz = CareerVisualizer(output_dir=output_dir)
    chart_matches = viz.plot_top_matches(results_df.head(top_k), filename="top_career_matches.png")
    chart_gap = viz.plot_skill_gaps(df_gap, target_occupation=top_title, filename="skill_gap_comparison.png")
    chart_heatmap = viz.plot_metric_correlation(comp_analysis["rank_correlation_matrix"], filename="metric_correlation_heatmap.png")

    # Step 7: Export CSV Files
    rec_csv = os.path.join(output_dir, "career_recommendations.csv")
    top_csv = os.path.join(output_dir, "top_career_matches.csv")
    gap_csv = os.path.join(output_dir, "skill_gap_analysis.csv")
    method_csv = os.path.join(output_dir, "method_comparison.csv")

    results_df.to_csv(rec_csv, index=False)
    results_df.head(top_k).to_csv(top_csv, index=False)
    df_gap.to_csv(gap_csv, index=False)
    comp_analysis["rank_correlation_matrix"].to_csv(method_csv)

    # Step 8: Export Run Summary Provenance
    summary_data = {
        "project": "AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis",
        "student": "ASHEN PAUL P - URK24CS1131",
        "academic_year": "2026-2027",
        "institution": "Karunya Institute of Technology and Sciences",
        "run_timestamp": run_timestamp,
        "dataset_source": "O*NET 30.2 / 31.0 Transferable Skills Dataset",
        "initial_raw_rows": preprocessor.cleaning_stats.get("initial_skill_rows"),
        "retained_cleaned_rows": preprocessor.cleaning_stats.get("retained_skill_rows"),
        "total_occupations_evaluated": len(results_df),
        "total_skills_dimension": len(matrix_df.columns),
        "scale_applied": scale,
        "learner_profile_type": profile_choice,
        "learner_skills_input": learner_dict,
        "top_1_recommendation": {
            "soc_code": top_soc,
            "title": top_title,
            "cosine_similarity": float(top_match["Cosine_Similarity"]),
            "readiness_index": float(top_match["Readiness_Index"])
        },
        "top_10_shortlist": results_df.head(top_k)[["Rank", "SOC_Code", "Occupation_Title", "Cosine_Similarity", "Readiness_Index"]].to_dict(orient="records"),
        "gap_analysis_summary": gap_summary,
        "spearman_rank_correlation_with_weighted": float(comp_analysis["rank_correlation_matrix"].loc["Cosine_Similarity", "Weighted_Cosine_Similarity"]),
        "artifacts_generated": [
            rec_csv, top_csv, gap_csv, method_csv,
            chart_matches, chart_gap, chart_heatmap
        ]
    }

    summary_json = os.path.join(output_dir, "run_summary.json")
    with open(summary_json, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=4)

    # Terminal Output Presentation
    print("\n" + "=" * 70)
    print("                 AI-ENHANCED CAREER GUIDANCE RESULTS")
    print("=" * 70)
    print(f"Learner Profile : {profile_choice}")
    print(f"Top Recommended : {top_title} (SOC: {top_soc})")
    print(f"Cosine Match    : {top_match['Cosine_Similarity']}%  |  Readiness: {top_match['Readiness_Index']}%")
    print("-" * 70)
    print("TOP 5 CAREER MATCHES:")
    print(results_df.head(5)[["Rank", "SOC_Code", "Occupation_Title", "Cosine_Similarity", "Readiness_Index"]].to_string(index=False))
    print("-" * 70)
    print("TOP 3 SKILL GAPS TO BRIDGE FOR TOP RECOMMENDATION:")
    for d in gap_summary["top_priority_growth_areas"][:3]:
        print(f"  * {d['Skill_Name']}: Deficit = +{d['Skill_Gap']:.1f} (Required: {d['Required_Proficiency']:.1f}, Learner: {d['Learner_Proficiency']:.1f})")
    print("-" * 70)
    print(f"All outputs exported to folder: '{os.path.abspath(output_dir)}'")
    print("=" * 70 + "\n")

    return summary_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AI-Enhanced Career Guidance System (URK24CS1131)")
    parser.add_argument("--scale", choices=["composite", "IM", "LV"], default="composite", help="Proficiency scale")
    parser.add_argument("--profile", choices=["data_science_ai", "software_engineering", "cybersecurity"], default="data_science_ai", help="Preset profile")
    parser.add_argument("--interactive", action="store_true", help="Run interactive terminal prompt")
    parser.add_argument("--top_k", type=int, default=10, help="Number of top matches")
    parser.add_argument("--output_dir", default="outputs", help="Output directory")

    args = parser.parse_args()

    # If user executes directly without flags in terminal, check if stdin is interactive
    is_interactive = args.interactive
    # If explicitly run with interactive flag, enable prompt
    run_pipeline(
        scale=args.scale,
        profile_choice=args.profile,
        interactive=is_interactive,
        top_k=args.top_k,
        output_dir=args.output_dir
    )
