"""
Module: preprocessor.py
Project: AI-Enhanced Career Guidance Using Skill Similarity and Skill-Gap Analysis
Student: ASHEN PAUL P - URK24CS1131
Course: Data Science Ecosystem

Implements schema validation, data cleaning, filtering by scale (Importance / Level / Composite),
and transforms long-form skill records into an aligned Occupation-Skill matrix.
"""

import os
import json
import logging
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

ESSENTIAL_SKILLS_COLS = ["O*NET-SOC Code", "Element Name", "Scale ID", "Data Value"]
ESSENTIAL_OCC_COLS = ["O*NET-SOC Code", "Title"]

# Standard 35 Transferable Skills in O*NET Content Model
STANDARD_ONET_SKILLS = [
    "Reading Comprehension", "Active Listening", "Writing", "Speaking",
    "Mathematics", "Science", "Critical Thinking", "Active Learning",
    "Learning Strategies", "Monitoring", "Social Perceptiveness", "Coordination",
    "Persuasion", "Negotiation", "Instructing", "Service Orientation",
    "Complex Problem Solving", "Operations Analysis", "Technology Design",
    "Equipment Selection", "Programming", "Operations Monitoring",
    "Operation and Control", "Equipment Maintenance", "Troubleshooting",
    "Repairing", "Quality Control Analysis", "Judgment and Decision Making",
    "Systems Analysis", "Systems Evaluation", "Time Management",
    "Management of Financial Resources", "Management of Material Resources",
    "Management of Personnel Resources"
]


class OnetPreprocessor:
    """
    Validates, cleans, and transforms raw O*NET data tables into a numerical matrix.
    """

    def __init__(self, raw_dir: str = "data/raw", processed_dir: str = "data/processed"):
        self.raw_dir = raw_dir
        self.processed_dir = processed_dir
        self.skills_file = os.path.join(raw_dir, "Skills.txt")
        self.occ_file = os.path.join(raw_dir, "Occupation Data.txt")
        self.cleaning_stats = {}

    def validate_schema(self, df_skills: pd.DataFrame, df_occ: pd.DataFrame):
        """
        Validates column presence and types according to O*NET data dictionary.
        """
        for col in ESSENTIAL_SKILLS_COLS:
            if col not in df_skills.columns:
                raise ValueError(f"Skills dataset missing essential column: '{col}'")

        for col in ESSENTIAL_OCC_COLS:
            if col not in df_occ.columns:
                raise ValueError(f"Occupation dataset missing essential column: '{col}'")

        logger.info("Schema validation passed successfully for both tables.")

    def clean_and_reshape(self, scale_preference: str = "composite") -> pd.DataFrame:
        """
        Cleans records, removes missing values, normalizes ratings, and pivots to matrix.
        
        scale_preference options:
          - 'IM': Importance scale (1.0 to 5.0), normalized to 0-100
          - 'LV': Level scale (0.0 to 7.0), normalized to 0-100
          - 'composite': Geometric mean of normalized IM and LV: sqrt(IM_norm * LV_norm) * 100
        """
        if not os.path.exists(self.skills_file) or not os.path.exists(self.occ_file):
            raise FileNotFoundError("Raw data files not found. Run data_loader first.")

        logger.info(f"Loading raw O*NET files from {self.raw_dir}...")
        df_skills_raw = pd.read_csv(self.skills_file, sep="\t", low_memory=False)
        df_occ_raw = pd.read_csv(self.occ_file, sep="\t", low_memory=False)

        initial_skill_rows = len(df_skills_raw)
        initial_occ_rows = len(df_occ_raw)

        self.validate_schema(df_skills_raw, df_occ_raw)

        # 1. Strip whitespace on string columns
        for c in ["O*NET-SOC Code", "Element Name", "Scale ID"]:
            df_skills_raw[c] = df_skills_raw[c].astype(str).str.strip()

        for c in ["O*NET-SOC Code", "Title"]:
            df_occ_raw[c] = df_occ_raw[c].astype(str).str.strip()

        # 2. Convert Data Value to numeric, coerce errors
        df_skills_raw["Data Value"] = pd.to_numeric(df_skills_raw["Data Value"], errors="coerce")

        # 3. Filter out invalid rows (missing code, skill name, or rating)
        df_skills_clean = df_skills_raw.dropna(subset=["O*NET-SOC Code", "Element Name", "Scale ID", "Data Value"]).copy()
        
        # Keep only IM and LV scales
        df_skills_clean = df_skills_clean[df_skills_clean["Scale ID"].isin(["IM", "LV"])]

        # Filter out suppression flags if recommended
        if "Recommend Suppress" in df_skills_clean.columns:
            df_skills_clean = df_skills_clean[df_skills_clean["Recommend Suppress"] != "Y"]

        retained_skill_rows = len(df_skills_clean)

        # 4. Merge with Occupation Titles
        df_merged = pd.merge(
            df_skills_clean,
            df_occ_raw[["O*NET-SOC Code", "Title", "Description"] if "Description" in df_occ_raw.columns else ["O*NET-SOC Code", "Title"]],
            on="O*NET-SOC Code",
            how="inner"
        )

        logger.info(f"Merged skills with occupations: {len(df_merged)} rows.")

        # 5. Normalize according to scale
        # IM is on 1 to 5 scale -> (IM - 1) / 4 * 100
        # LV is on 0 to 7 scale -> LV / 7 * 100
        if scale_preference == "IM":
            df_im = df_merged[df_merged["Scale ID"] == "IM"].copy()
            df_im["Score"] = ((df_im["Data Value"] - 1.0) / 4.0).clip(0.0, 1.0) * 100.0
            matrix_df = df_im.pivot_table(index=["O*NET-SOC Code", "Title"], columns="Element Name", values="Score")
        elif scale_preference == "LV":
            df_lv = df_merged[df_merged["Scale ID"] == "LV"].copy()
            df_lv["Score"] = (df_lv["Data Value"] / 7.0).clip(0.0, 1.0) * 100.0
            matrix_df = df_lv.pivot_table(index=["O*NET-SOC Code", "Title"], columns="Element Name", values="Score")
        else: # composite
            pivoted = df_merged.pivot_table(
                index=["O*NET-SOC Code", "Title"],
                columns=["Element Name", "Scale ID"],
                values="Data Value"
            )
            # Reconstruct composite score
            skills_present = pivoted.columns.levels[0]
            composite_data = {}
            for sk in skills_present:
                try:
                    im_val = pivoted[(sk, "IM")]
                    lv_val = pivoted[(sk, "LV")]
                    im_norm = ((im_val - 1.0) / 4.0).clip(0.0, 1.0)
                    lv_norm = (lv_val / 7.0).clip(0.0, 1.0)
                    composite_data[sk] = np.sqrt(im_norm * lv_norm) * 100.0
                except KeyError:
                    # In case one scale is missing
                    if (sk, "IM") in pivoted.columns:
                        composite_data[sk] = ((pivoted[(sk, "IM")] - 1.0) / 4.0).clip(0.0, 1.0) * 100.0
                    elif (sk, "LV") in pivoted.columns:
                        composite_data[sk] = (pivoted[(sk, "LV")] / 7.0).clip(0.0, 1.0) * 100.0

            matrix_df = pd.DataFrame(composite_data, index=pivoted.index)

        # 6. Fill missing values (policy: unrated skill assumed minimum proficiency = 0.0)
        matrix_df = matrix_df.fillna(0.0).round(2)

        # 7. Record cleaning statistics for repeatability and report
        self.cleaning_stats = {
            "initial_skill_rows": int(initial_skill_rows),
            "retained_skill_rows": int(retained_skill_rows),
            "initial_occupations": int(initial_occ_rows),
            "final_occupations_in_matrix": int(len(matrix_df)),
            "distinct_skills_count": int(len(matrix_df.columns)),
            "scale_preference": scale_preference,
            "feature_skills": list(matrix_df.columns)
        }

        # 8. Export processed matrix & metadata
        os.makedirs(self.processed_dir, exist_ok=True)
        matrix_out_path = os.path.join(self.processed_dir, "occupation_skill_matrix.csv")
        matrix_df.to_csv(matrix_out_path)
        
        meta_out_path = os.path.join(self.processed_dir, "skill_metadata.json")
        with open(meta_out_path, "w", encoding="utf-8") as f:
            json.dump(self.cleaning_stats, f, indent=4)

        logger.info(f"Processed Occupation-Skill matrix saved to {matrix_out_path}")
        logger.info(f"Matrix shape: {matrix_df.shape} ({matrix_df.shape[0]} occupations x {matrix_df.shape[1]} skills)")
        return matrix_df

    def get_feature_skills(self) -> list:
        """Returns the list of skill column names."""
        meta_out_path = os.path.join(self.processed_dir, "skill_metadata.json")
        if os.path.exists(meta_out_path):
            with open(meta_out_path, "r", encoding="utf-8") as f:
                return json.load(f).get("feature_skills", STANDARD_ONET_SKILLS)
        return STANDARD_ONET_SKILLS


if __name__ == "__main__":
    preprocessor = OnetPreprocessor()
    df_mat = preprocessor.clean_and_reshape(scale_preference="composite")
    print(df_mat.head())
